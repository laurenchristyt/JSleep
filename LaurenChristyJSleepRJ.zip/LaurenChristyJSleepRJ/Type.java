package LaurenChristyJSleepRJ;

public enum Type
{
    REBATE, DISCOUNT  
}
