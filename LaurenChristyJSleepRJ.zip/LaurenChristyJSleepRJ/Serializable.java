package LaurenChristyJSleepRJ;

public class Serializable
{
    public final int id;
    
    public Serializable(int id){
        this.id = id;
    }
}
