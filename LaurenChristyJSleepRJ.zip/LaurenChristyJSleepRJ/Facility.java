package LaurenChristyJSleepRJ;

public enum Facility
{
    WiFi, Bathtub, Balcony, AC, FitnessCenter, Refrigerator, Restaurant, SwimmingPool
}
